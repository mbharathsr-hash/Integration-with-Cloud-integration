import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.pd.PartnerDirectoryService;
import com.sap.it.api.ITApiFactory;
import src.main.resources.script.PipelineLogger;

def Message processData(Message message) {
    
    def service = ITApiFactory.getApi(PartnerDirectoryService.class, null); 
    if (service == null){
        throw new IllegalStateException("Partner Directory Service not found");
    }
    
    // get headers & properties
    def properties = message.getProperties()
    def messageLog = messageLogFactory.getMessageLog(message)
    def headers = message.getHeaders()
    def ReceiverAlias = headers.get("SAP_ReceiverAlias")
    def PipelineJMSQueuePrefix = properties.get("PipelineJMSQueuePrefix")
    
    // First check if receiver-specific queue is maintained for a particular configuration scenario
    String Pid = headers.get("partnerID");
    def receiverSpecificQueue = service.getParameter("ReceiverSpecificQueue_" + ReceiverAlias, Pid , String.class);

    // If not, check if receiver-specific queue is maintained for the particular receiver    
    if (receiverSpecificQueue == null) {
        receiverSpecificQueue = service.getParameter("ReceiverSpecificQueue", ReceiverAlias , String.class);
    }
    
    // if the receiver-specific queue exists, create a new exchange property containing the queue name
    // otherwise, the exchange property is not created
    message.setProperty("receiverSpecificQueueName", receiverSpecificQueue ?: null);
    
    // create a new exchange property with value true or false depending on whether the queue exists
    message.setProperty("receiverSpecificQueueBoolean", receiverSpecificQueue ? 'true' : 'false');
    
    // add receiver JMS queue name to custom header properties
    if (receiverSpecificQueue) {
        messageLog?.addCustomHeaderProperty("ReceiverJMSQueue", receiverSpecificQueue)
    } else if (!receiverSpecificQueue && PipelineJMSQueuePrefix) {
        messageLog?.addCustomHeaderProperty("ReceiverJMSQueue", PipelineJMSQueuePrefix + 'Q04')
    }

	// adding information to audit log using helper PipelineLogger class
	PipelineLogger logger = PipelineLogger.newLogger(message, "auditLog")
	logger.addEntry("readReceiverSpecificQueueFromPD", "Header SAP_ReceiverAlias=" + (message.headers.SAP_ReceiverAlias ?: "n/a") + ".")
	logger.addEntry("readReceiverSpecificQueueFromPD", "PID to read the receiver-specific JMS queue from the Partner Directory: " + (Pid ?: "n/a") + ".")
	logger.addEntry("readReceiverSpecificQueueFromPD", "Receiver specific queue from the Partner Directory: property receiverSpecificQueueName=" + (message.properties.receiverSpecificQueueName.toString() ?: "n/a") + ".")
	logger.addEntry("readReceiverSpecificQueueFromPD", "Receiver specific queue existence from the Partner Directory: property receiverSpecificQueueBoolean=" + (message.properties.receiverSpecificQueueBoolean.toString() ?: "n/a") + ".")
	if (logger.getLog()) { 
	    logger.saveToMessage(message)
	}

    return message;
}